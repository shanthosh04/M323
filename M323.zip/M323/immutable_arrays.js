function group(bewertungen) {
    return bewertungen.reduce(function (resultat, bewertung) {
        if (bewertung >= 4) {
            resultat.good++;
        } else if (bewertung >= 2.5) {
            resultat.ok++;
        } else {
            resultat.bad++;
        }
        return resultat;
    }, { good: 0, ok: 0, bad: 0 });
}

const reviews = [4.5, 4.0, 5.0, 2.0, 1.0, 5.0, 3.0, 4.0, 1.0, 5.0, 4.5, 3.0, 2.5, 2.0];

const feedbackgroup = group(reviews);

console.log("Anzahl der guten Bewertungen:", feedbackgroup.good);
console.log("Anzahl der okay Bewertungen:", feedbackgroup.ok);
console.log("Anzahl der schlechten Bewertungen:", feedbackgroup.bad);

