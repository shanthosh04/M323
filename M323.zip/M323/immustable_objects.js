const person = {
    name: "Shanthosh",
    age: 30,
    job: "Computer Scientiest",
  };
  

  const addPerson = {
    name: "Shanthosh",
    alter: 30,
    job: "Computer Scientiest",
    city: "Liebefeld" ,
  };
  
  console.log(addPerson);
  
  