const rateStudent = (gradingScale) => (student) => {
    const { name, grade } = student;
    let feedback = '';
    
    if (grade >= 90) {
      feedback = 'Excellent Job';
    } else if (grade >= 80) {
      feedback = 'Nice Job';
    } else if (grade >= 70) {
      feedback = 'Well done';
    } else if (grade >= 60) {
      feedback = 'What happened';
    } else {
      feedback = 'Not good';
    }
  
    feedback += ` ${name}, you got an ${gradingScale(grade)}`;
  
    return feedback;
  };

  const assignGrade = (grade) => {
    if (grade >= 90) {
      return 'a';
    } else if (grade >= 80) {
      return 'b';
    } else if (grade >= 70) {
      return 'c';
    } else if (grade >= 60) {
      return 'd';
    } else {
      return 'f';
    }
  };
  
  const Grades = [ 
    { name: 'Joe', grade: 88 },
    { name: 'Jen', grade: 94 },
    { name: 'Steph', grade: 77 },
    { name: 'Allen', grade: 60 },
    { name: 'Gina', grade: 54 },
  ];
  
  const Feedback = Grades.map(rateStudent(assignGrade));
  
  console.log(Feedback);
  
  module.exports = { rateStudent, assignGrade };
  